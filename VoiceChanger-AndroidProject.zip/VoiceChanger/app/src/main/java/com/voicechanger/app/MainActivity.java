package com.voicechanger.app;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int PERM_REQUEST = 100;

    private VoiceChangerService service;
    private boolean             bound   = false;
    private boolean             running = false;

    // UI
    private Button   btnStart;
    private TextView tvStatus;
    private TextView tvEffect;
    private SeekBar  seekVolume;
    private CardView[] effectCards;
    private AudioProcessor.VoiceEffect selectedEffect = AudioProcessor.VoiceEffect.NORMAL;

    // ---------------------------------------------------------------
    // Service connection
    // ---------------------------------------------------------------

    private final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) {
            service = ((VoiceChangerService.LocalBinder) b).getService();
            bound   = true;
        }
        @Override public void onServiceDisconnected(ComponentName n) {
            bound = false;
        }
    };

    // ---------------------------------------------------------------
    // Lifecycle
    // ---------------------------------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindViews();
        setupEffectButtons();
        setupVolumeSlider();
        setupStartButton();
        checkPermissions();
    }

    @Override
    protected void onStart() {
        super.onStart();
        Intent intent = new Intent(this, VoiceChangerService.class);
        startForegroundService(intent);
        bindService(intent, conn, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (bound) { unbindService(conn); bound = false; }
    }

    // ---------------------------------------------------------------
    // UI Setup
    // ---------------------------------------------------------------

    private void bindViews() {
        btnStart   = findViewById(R.id.btn_start);
        tvStatus   = findViewById(R.id.tv_status);
        tvEffect   = findViewById(R.id.tv_effect);
        seekVolume = findViewById(R.id.seek_volume);

        effectCards = new CardView[] {
            findViewById(R.id.card_normal),
            findViewById(R.id.card_baby),
            findViewById(R.id.card_female),
            findViewById(R.id.card_robot),
            findViewById(R.id.card_deep),
            findViewById(R.id.card_chipmunk)
        };
    }

    private void setupEffectButtons() {
        AudioProcessor.VoiceEffect[] effects = AudioProcessor.VoiceEffect.values();
        String[] labels = {"Normal", "Baby", "Female", "Robot", "Deep", "Chipmunk"};

        for (int i = 0; i < effectCards.length; i++) {
            final AudioProcessor.VoiceEffect effect = effects[i];
            final String label = labels[i];
            effectCards[i].setOnClickListener(v -> {
                selectedEffect = effect;
                tvEffect.setText("Effect: " + label);
                highlightCard(v);
                if (bound) service.setEffect(effect);
            });
        }

        // Highlight Normal by default
        highlightCard(effectCards[0]);
    }

    private void highlightCard(View selected) {
        int active   = getColor(R.color.accent);
        int inactive = getColor(R.color.card_bg);
        for (CardView c : effectCards) {
            c.setCardBackgroundColor(c == selected ? active : inactive);
        }
    }

    private void setupVolumeSlider() {
        seekVolume.setMax(200);
        seekVolume.setProgress(100);
        seekVolume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean u) {
                if (bound) service.setVolume(p / 100f);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });
    }

    private void setupStartButton() {
        btnStart.setOnClickListener(v -> {
            if (!running) startChanger();
            else          stopChanger();
        });
    }

    // ---------------------------------------------------------------
    // Voice changer control
    // ---------------------------------------------------------------

    private void startChanger() {
        if (!bound) { toast("Service not ready"); return; }
        if (!isBluetoothHeadsetConnected()) {
            toast("⚠️ No Bluetooth headset detected!\nConnect BT headphones first.");
            // Still allow start in case detection fails
        }
        service.setEffect(selectedEffect);
        service.startVoiceChanger();
        running = true;
        btnStart.setText("⏹ STOP");
        btnStart.setBackgroundColor(getColor(R.color.red));
        tvStatus.setText("🔴 LIVE — BT Mic → Processing → AUX Out");
    }

    private void stopChanger() {
        if (bound) service.stopVoiceChanger();
        running = false;
        btnStart.setText("▶ START");
        btnStart.setBackgroundColor(getColor(R.color.accent));
        tvStatus.setText("⚪ Stopped — connect BT headphones & AUX cable");
    }

    // ---------------------------------------------------------------
    // Bluetooth check
    // ---------------------------------------------------------------

    private boolean isBluetoothHeadsetConnected() {
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            return adapter != null &&
                   adapter.isEnabled() &&
                   adapter.getProfileConnectionState(BluetoothProfile.HEADSET)
                       == BluetoothProfile.STATE_CONNECTED;
        } catch (SecurityException e) {
            return false;
        }
    }

    // ---------------------------------------------------------------
    // Permissions
    // ---------------------------------------------------------------

    private void checkPermissions() {
        String[] perms = {
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.MODIFY_AUDIO_SETTINGS,
            Manifest.permission.BLUETOOTH_CONNECT,
        };
        boolean allGranted = true;
        for (String p : perms) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                allGranted = false; break;
            }
        }
        if (!allGranted) ActivityCompat.requestPermissions(this, perms, PERM_REQUEST);
    }

    @Override
    public void onRequestPermissionsResult(int req, @NonNull String[] perms,
                                           @NonNull int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        for (int r : results) {
            if (r != PackageManager.PERMISSION_GRANTED) {
                toast("Microphone permission required!"); return;
            }
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }
}
