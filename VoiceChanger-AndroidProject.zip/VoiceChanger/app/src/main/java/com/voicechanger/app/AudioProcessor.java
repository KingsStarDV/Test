package com.voicechanger.app;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.util.Log;

/**
 * Core audio processing engine.
 *
 * AUDIO ROUTING:
 *   INPUT:  Bluetooth SCO mic (headphone) → AudioRecord (VOICE_COMMUNICATION source)
 *   OUTPUT: AudioTrack (STREAM_MUSIC) → wired 3.5mm jack (aux out to second phone)
 *
 * VOICE EFFECTS implemented in pure Java DSP:
 *   - Baby    : pitch up 1.8x + slight reverb
 *   - Female  : pitch up 1.3x + formant hint
 *   - Robot   : ring modulation at 60Hz
 *   - Deep    : pitch down 0.6x (demon)
 *   - Chipmunk: pitch up 2.5x
 *   - Normal  : passthrough
 */
public class AudioProcessor {

    private static final String TAG = "AudioProcessor";

    // Audio config — 16kHz mono is plenty for voice, keeps latency low
    public static final int SAMPLE_RATE = 16000;
    private static final int CHANNEL_IN  = AudioFormat.CHANNEL_IN_MONO;
    private static final int CHANNEL_OUT = AudioFormat.CHANNEL_OUT_MONO;
    private static final int ENCODING    = AudioFormat.ENCODING_PCM_16BIT;

    public enum VoiceEffect { NORMAL, BABY, FEMALE, ROBOT, DEEP, CHIPMUNK }

    private AudioRecord audioRecord;
    private AudioTrack  audioTrack;

    private volatile boolean running = false;
    private volatile VoiceEffect currentEffect = VoiceEffect.NORMAL;
    private volatile float volume = 1.0f;

    private Thread processingThread;

    // ---------------------------------------------------------------
    // Lifecycle
    // ---------------------------------------------------------------

    public boolean init() {
        int bufferSize = Math.max(
            AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_IN, ENCODING),
            AudioTrack.getMinBufferSize(SAMPLE_RATE, CHANNEL_OUT, ENCODING)
        ) * 4; // 4× for safety

        try {
            // INPUT: prefer BLUETOOTH SCO so we capture from BT headphone mic
            audioRecord = new AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                SAMPLE_RATE, CHANNEL_IN, ENCODING, bufferSize
            );

            // OUTPUT: STREAM_MUSIC → wired audio jack (when BT is connected,
            // Android routes MUSIC to wired jack, keeping SCO for mic)
            audioTrack = new AudioTrack(
                AudioManager.STREAM_MUSIC,
                SAMPLE_RATE, CHANNEL_OUT, ENCODING,
                bufferSize, AudioTrack.MODE_STREAM
            );

            if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED ||
                audioTrack.getState()  != AudioTrack.STATE_INITIALIZED) {
                Log.e(TAG, "Audio init failed");
                return false;
            }
            return true;
        } catch (Exception e) {
            Log.e(TAG, "init error", e);
            return false;
        }
    }

    public void start() {
        if (running) return;
        running = true;
        audioRecord.startRecording();
        audioTrack.play();

        processingThread = new Thread(this::processingLoop, "VoiceChanger-DSP");
        processingThread.setPriority(Thread.MAX_PRIORITY);
        processingThread.start();
        Log.i(TAG, "Started — effect: " + currentEffect);
    }

    public void stop() {
        running = false;
        if (processingThread != null) {
            try { processingThread.join(2000); } catch (InterruptedException ignored) {}
        }
        if (audioRecord != null) { audioRecord.stop(); audioRecord.release(); audioRecord = null; }
        if (audioTrack  != null) { audioTrack.stop();  audioTrack.release();  audioTrack  = null; }
        Log.i(TAG, "Stopped");
    }

    public void setEffect(VoiceEffect effect) { this.currentEffect = effect; }
    public void setVolume(float v)            { this.volume = Math.max(0f, Math.min(2f, v)); }
    public VoiceEffect getEffect()            { return currentEffect; }

    // ---------------------------------------------------------------
    // Main DSP loop
    // ---------------------------------------------------------------

    private void processingLoop() {
        // chunk = 20ms of audio — good balance of latency vs CPU
        int chunkSamples = SAMPLE_RATE / 50;
        short[] inBuf  = new short[chunkSamples];
        short[] outBuf;

        while (running) {
            int read = audioRecord.read(inBuf, 0, chunkSamples);
            if (read <= 0) continue;

            short[] chunk = (read == chunkSamples) ? inBuf : java.util.Arrays.copyOf(inBuf, read);

            switch (currentEffect) {
                case BABY:      outBuf = pitchShift(chunk, 1.80f); outBuf = addReverb(outBuf, 0.25f); break;
                case FEMALE:    outBuf = pitchShift(chunk, 1.30f); break;
                case ROBOT:     outBuf = ringModulate(chunk, 60f);  break;
                case DEEP:      outBuf = pitchShift(chunk, 0.60f); break;
                case CHIPMUNK:  outBuf = pitchShift(chunk, 2.50f); break;
                default:        outBuf = chunk; break;
            }

            // Apply volume
            if (volume != 1.0f) applyVolume(outBuf, volume);

            audioTrack.write(outBuf, 0, outBuf.length);
        }
    }

    // ---------------------------------------------------------------
    // DSP Effects
    // ---------------------------------------------------------------

    /**
     * Simple time-domain pitch shift via linear resampling.
     * factor > 1 → higher pitch,  factor < 1 → lower pitch.
     * Works well enough for voice in real-time without FFT overhead.
     */
    private short[] pitchShift(short[] in, float factor) {
        int outLen = Math.round(in.length / factor);
        short[] out = new short[outLen];
        for (int i = 0; i < outLen; i++) {
            float srcPos = i * factor;
            int   lo     = (int) srcPos;
            float frac   = srcPos - lo;
            int   hi     = Math.min(lo + 1, in.length - 1);
            lo = Math.min(lo, in.length - 1);
            // linear interpolation
            out[i] = (short) (in[lo] * (1f - frac) + in[hi] * frac);
        }
        return out;
    }

    /**
     * Ring modulation: multiply signal by a sine carrier.
     * Produces a robotic / metallic effect.
     */
    private float ringPhase = 0f;
    private short[] ringModulate(short[] in, float carrierHz) {
        short[] out = new short[in.length];
        float phaseStep = (float) (2.0 * Math.PI * carrierHz / SAMPLE_RATE);
        for (int i = 0; i < in.length; i++) {
            float mod = (float) Math.sin(ringPhase);
            out[i]    = clamp(in[i] * mod * 1.5f);
            ringPhase += phaseStep;
            if (ringPhase > 2 * Math.PI) ringPhase -= 2 * Math.PI;
        }
        return out;
    }

    /**
     * Simple feedback reverb (comb filter).
     */
    private short[] reverbBuffer = new short[SAMPLE_RATE / 4]; // 250ms delay
    private int     reverbIdx    = 0;

    private short[] addReverb(short[] in, float wet) {
        short[] out = new short[in.length];
        for (int i = 0; i < in.length; i++) {
            short delayed = reverbBuffer[reverbIdx];
            float mixed   = in[i] * (1f - wet) + delayed * wet;
            out[i]        = clamp(mixed);
            reverbBuffer[reverbIdx] = out[i];
            reverbIdx = (reverbIdx + 1) % reverbBuffer.length;
        }
        return out;
    }

    private void applyVolume(short[] buf, float vol) {
        for (int i = 0; i < buf.length; i++) {
            buf[i] = clamp(buf[i] * vol);
        }
    }

    private static short clamp(float val) {
        if (val > Short.MAX_VALUE) return Short.MAX_VALUE;
        if (val < Short.MIN_VALUE) return Short.MIN_VALUE;
        return (short) val;
    }
}
