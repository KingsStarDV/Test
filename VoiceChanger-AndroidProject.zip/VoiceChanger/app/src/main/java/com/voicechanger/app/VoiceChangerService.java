package com.voicechanger.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothHeadset;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import androidx.core.app.NotificationCompat;

public class VoiceChangerService extends Service {

    private static final String TAG     = "VCService";
    private static final String CHAN_ID = "voice_changer_channel";
    private static final int    NOTIF_ID = 1;

    private final IBinder binder = new LocalBinder();

    private AudioProcessor processor;
    private AudioManager   audioManager;
    private boolean        scoStarted = false;

    // ---------------------------------------------------------------
    // Binder
    // ---------------------------------------------------------------

    public class LocalBinder extends Binder {
        public VoiceChangerService getService() { return VoiceChangerService.this; }
    }

    @Override public IBinder onBind(Intent intent) { return binder; }

    // ---------------------------------------------------------------
    // Lifecycle
    // ---------------------------------------------------------------

    @Override
    public void onCreate() {
        super.onCreate();
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        processor    = new AudioProcessor();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIF_ID, buildNotification());
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        stopVoiceChanger();
        super.onDestroy();
    }

    // ---------------------------------------------------------------
    // Public API (called from MainActivity)
    // ---------------------------------------------------------------

    public boolean startVoiceChanger() {
        enableBluetoothSco();

        // Small delay to let SCO connect
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
            if (processor.init()) {
                processor.start();
                Log.i(TAG, "Voice changer started");
            } else {
                Log.e(TAG, "Processor init failed");
            }
        }, 800);

        return true;
    }

    public void stopVoiceChanger() {
        if (processor != null) processor.stop();
        disableBluetoothSco();
    }

    public void setEffect(AudioProcessor.VoiceEffect effect) {
        if (processor != null) processor.setEffect(effect);
    }

    public void setVolume(float v) {
        if (processor != null) processor.setVolume(v);
    }

    public AudioProcessor.VoiceEffect getEffect() {
        return processor != null ? processor.getEffect() : AudioProcessor.VoiceEffect.NORMAL;
    }

    // ---------------------------------------------------------------
    // Bluetooth SCO — routes mic input from BT headphone
    // ---------------------------------------------------------------

    private void enableBluetoothSco() {
        try {
            audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
            audioManager.startBluetoothSco();
            audioManager.setBluetoothScoOn(true);
            scoStarted = true;
            Log.i(TAG, "Bluetooth SCO started");
        } catch (Exception e) {
            Log.e(TAG, "SCO start error: " + e.getMessage());
        }
    }

    private void disableBluetoothSco() {
        if (scoStarted) {
            try {
                audioManager.stopBluetoothSco();
                audioManager.setBluetoothScoOn(false);
                audioManager.setMode(AudioManager.MODE_NORMAL);
                scoStarted = false;
            } catch (Exception e) {
                Log.e(TAG, "SCO stop error: " + e.getMessage());
            }
        }
    }

    // ---------------------------------------------------------------
    // Notification
    // ---------------------------------------------------------------

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
            CHAN_ID, "Voice Changer", NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription("Live voice processing");
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.createNotificationChannel(channel);
    }

    private Notification buildNotification() {
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        return new NotificationCompat.Builder(this, CHAN_ID)
            .setContentTitle("🎙️ Voice Changer Active")
            .setContentText("Bluetooth → Processing → AUX out")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true)
            .build();
    }
}
