# 🎙️ Voice Changer — BT Mic → Process → AUX Out

## What This Does

```
Bluetooth Headphones (your mic)
        ↓
  [This Android App]
  ┌─────────────────────────────┐
  │  AudioRecord ← BT SCO mic  │
  │  DSP Engine (pitch/effects) │
  │  AudioTrack → 3.5mm jack   │
  └─────────────────────────────┘
        ↓ AUX cable
  Second Phone (3.5mm mic-in)
        ↓
  WhatsApp / Any call app
        ↓
  Other person hears changed voice ✅
```

## Hardware Setup

1. **Bluetooth headphones** → paired with THIS phone (used as mic input)
2. **3.5mm AUX cable** → from THIS phone's headphone jack → into 2nd phone's mic/headphone jack
3. On the 2nd phone: start your WhatsApp/regular call

> ⚠️ Some phones need a **TRRS splitter** on the 2nd phone to separate mic-in from audio-out.
> Buy a "3.5mm headphone splitter mic" on Amazon (~₹100).

## Voice Effects

| Effect | Pitch Factor | Extra |
|--------|-------------|-------|
| Normal | 1.0× | Passthrough |
| Baby | 1.8× | + Reverb |
| Female | 1.3× | Pitch up |
| Robot | — | Ring modulation @60Hz |
| Deep / Demon | 0.6× | Pitch down |
| Chipmunk | 2.5× | Extreme up |

## How to Build the APK

### Prerequisites
- Android Studio (free): https://developer.android.com/studio
- JDK 11 or 17

### Steps

1. **Open in Android Studio:**
   - File → Open → select the `VoiceChanger` folder

2. **Let Gradle sync** (downloads dependencies automatically)

3. **Build APK:**
   - Build → Build Bundle(s)/APK(s) → Build APK(s)
   - APK saved to: `app/build/outputs/apk/debug/app-debug.apk`

4. **Install on phone:**
   - Enable "Install from unknown sources" in Android Settings
   - Transfer APK to phone and install
   - OR: plug phone via USB, enable Developer Mode, click "Run" in Android Studio

### From Command Line (no Android Studio)
```bash
# Set ANDROID_HOME to your SDK path first
export ANDROID_HOME=~/Android/Sdk

cd VoiceChanger
chmod +x gradlew
./gradlew assembleDebug

# APK is at:
# app/build/outputs/apk/debug/app-debug.apk
```

## Permissions Required
- `RECORD_AUDIO` — capture from BT mic
- `MODIFY_AUDIO_SETTINGS` — route BT SCO
- `BLUETOOTH_CONNECT` — detect BT headset

## Troubleshooting

| Problem | Fix |
|---------|-----|
| No audio output | Check AUX cable is firmly connected both ends |
| 2nd phone not picking up audio | Try a TRRS splitter on 2nd phone |
| BT mic not capturing | Make sure BT headphones are connected BEFORE pressing START |
| Delay/latency | Reduce phone's audio buffer in developer options |
| Effect sounds weak | Turn up Output Volume slider in the app |

## Technical Notes

- **Sample rate:** 16kHz mono (low latency voice optimized)
- **Chunk size:** 20ms (good balance of latency vs CPU)
- **Pitch shift:** Linear time-domain resampling (real-time safe)
- **DSP thread:** Runs at MAX_PRIORITY to avoid glitches
- **Foreground service:** Keeps processing alive when screen is off
